#!/usr/bin/env python
# coding: utf-8

# # Harjoitustyö 2022
# 

# Määritetään käytettävät kirjastot

# In[1]:


import pandas as pd
import numpy as np
import requests
import os


# Ladataan halutut datatiedostot käyttäen URL-linkkejä

# In[2]:


#Määritetään tiedostojen osoitteet
stockholm_listingsfile = 'http://data.insideairbnb.com/sweden/stockholms-l%C3%A4n/stockholm/2021-12-28/visualisations/listings.csv'
stockholm_reviewsfile = 'http://data.insideairbnb.com/sweden/stockholms-l%C3%A4n/stockholm/2021-12-28/visualisations/reviews.csv'

#Tehdään kaksi dataframea
listings_stockholm = pd.read_csv(stockholm_listingsfile, compression='infer')
reviews_stockholm = pd.read_csv(stockholm_reviewsfile, compression='infer')


# In[3]:


#Tulostetaan eri sarakkeiden otsikot
print(listings_stockholm.columns.tolist())
print()
print(reviews_stockholm.columns.tolist())


# In[4]:


#Tulostetaan sarakkeet vielä .info() -komennon avulla
print(listings_stockholm.info())
print()
print(reviews_stockholm.info())


# In[5]:


#Valitaan halutut sarakkeet listings-dataframesta
st_listings = listings_stockholm[["id", "name", "neighbourhood", "room_type", "price",
                                  "number_of_reviews", "reviews_per_month", "number_of_reviews_ltm"]]

#Yhdistetään dataframet yhdeksi
df_new = pd.merge(st_listings, reviews_stockholm, left_on='id', right_on='listing_id')

#Tulostetaan uusi dataframe
df_new


# In[6]:


#Tarkistetaan vielä sarakkeet ja niiden datatyypit
print(df_new.info())


# In[7]:


#Etsitään mahdolliset tyhjäarvot
print(df_new.isnull().sum())


# In[8]:


#Muutetaan NaN-arvot nolliksi
df_new['name'] = df_new['name'].replace(np.nan, 0)


# In[9]:


#Haetaan rivit, jotka täyttävät ehdon
indexNames = df_new[ df_new['name'] == 0 ].index

#Poistetaan valitut rivit
df_new.drop(indexNames , inplace=True)
df_new


# In[10]:


#Haetaan rivit, jotka täyttävät ehdon
index = df_new[ df_new['number_of_reviews_ltm'] <= 2 ].index

#Poistetaan valitut rivit
df_new.drop(index , inplace=True)
df_new


# In[11]:


#Tutkitaan, mitä erilaisia kokoonpanoja asunnoilla on
print(df_new['room_type'].unique())


# In[12]:


#Piirretään kuvaaja asuntojen kokoonpanoista
import matplotlib.pyplot as figure
import matplotlib.pyplot as plt

plt.figure(figsize=(20,4))
plt.title('Asunnon kokoonpano')
df_new['room_type'].value_counts().plot(kind='bar', color='Black')


# In[13]:


#Poistetaan valitut rivit
df_new = df_new[df_new.room_type != 'Shared room']
df_new = df_new[df_new.room_type != 'Private room']
df_new = df_new[df_new.room_type != 'Hotel room']
df_new


# In[14]:


#Piirretään kuvaaja asuinalueista
plt.figure(figsize=(20,4))
plt.title('Asuinalueet')
df_new['neighbourhood'].value_counts().plot(kind='bar', color='Black')


# In[15]:


#Poistetaan valitut rivit
df_new = df_new[df_new.neighbourhood != 'Spånga-Tensta']
df_new = df_new[df_new.neighbourhood != 'Rinkeby-Tensta']
df_new = df_new[df_new.neighbourhood != 'Hässelby-Vällingby']
df_new = df_new[df_new.neighbourhood != 'Farsta']
df_new = df_new[df_new.neighbourhood != 'Ävsjö']
df_new = df_new[df_new.neighbourhood != 'Skärholmens']
df_new = df_new[df_new.neighbourhood != 'Skarpnäcks']
df_new = df_new[df_new.neighbourhood != 'Hägersten-Liljeholmens']
df_new


# In[16]:


#Poistetaan dublikaatit
df_new.drop_duplicates(subset=['id'])


# In[17]:


#Kuvaillaan dataa
df_new.describe()


# In[18]:


#Piirretään histogrammit
df_new.hist(bins=50, figsize=(28,15), color='Black')
plt.show
print()


# In[19]:


#Hintojen muuttuminen asuinalueittan
import seaborn as sbn

min_price = df_new['price'].min()
max_price = df_new['price'].max()
print('Minimihinta: ', min_price, ', Maksimihinta: ', max_price, '\n')
price_neighbourhood = sbn.catplot(kind='bar', x='neighbourhood', y='price', data=df_new, aspect = 3)
price_neighbourhood.set_xticklabels(rotation = 90, horizontalalignment = 'right')


# In[20]:


#Hinnan vaikutus arvostelujen määrään
review_price = df_new[['number_of_reviews', 'price']].sort_values(by='price')
figure = review_price.plot(x='price', y='number_of_reviews', style='*', color='Black', figsize=(7,7),                            legend=False, title= 'Arvostelujen määrä hinnan perusteella', fontsize=14)

figure.set_ylabel('Arvostelujen määrä', fontsize=14)
figure.set_xlabel('Hinta', fontsize=14)


# In[21]:


#Muodostetaan monimuuttujamatriisi
scattercols = ['price', 'neighbourhood', 'number_of_reviews', 'number_of_reviews_ltm', 'reviews_per_month', 'date']
axs = pd.plotting.scatter_matrix(df_new[scattercols], figsize=(15,10), color='Black')


# In[22]:


#Muodostetaan ympyrädiagrammi saatujen arvostelujen määrästä asuinalueesta riippuen
from collections import Counter
pie_nb = Counter(df_new.neighbourhood)
nb_df = pd.DataFrame.from_dict(pie_nb, orient='index').sort_values(by=0)
nb_df.columns = ['neighbourhood']
nb_df.plot.pie(y='neighbourhood', colormap='Blues_r', figsize=(8.5,8.5), fontsize=20, autopct='%.2f', legend=False)


# In[23]:


#Tutkitaan eri muuttujien korrelaatioita suhteessa asunnon hintaan
df_new.corr()['price']


# In[24]:


#Lineaarinen regressio
from sklearn import linear_model

linear_regression = linear_model.LinearRegression()
x = df_new['number_of_reviews_ltm'].values[:, np.newaxis]
y = df_new['price']

classifier = linear_regression.fit(x,y)

plt.scatter(x,y, color='blue')
plt.plot(x, classifier.predict(x), color='black')
plt.title('Arvioiden määrän vaikutus hintaan')
plt.xlabel('Arvioiden määrä')
plt.ylabel('Hinta')


# In[26]:


from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
import sklearn.ensemble as GradientBoostingRegessor
from sklearn import ensemble

#Muokataan hieman dataframea, jotta monimuuttujaregressio onnistuu
df = df_new[["id", "price", "number_of_reviews", "reviews_per_month", "number_of_reviews_ltm", 'listing_id']]

#Monimuuttujaregressio
x_train, x_test, y_train, y_test =train_test_split(df.drop(['price'], axis=1),
                                                  df.price, test_size=0.2, random_state=20)
tuned_parameters = {
    'n_estimators' : [600],
    'max_depth' : [4],
    'learning_rate' : [0.01],
    'min_samples_split' : [2],
    'loss' : ['ls', 'lad']
}

gbr = ensemble.GradientBoostingRegressor()
clf = GridSearchCV(gbr, cv=3, param_grid=tuned_parameters, scoring='neg_median_absolute_error')
predictions = clf.fit(x_train, y_train)
best = clf.best_estimator_
best


# In[27]:


abs(clf.best_score_)


# In[31]:


feature_importance = best.feature_importances_
feature_importance = 100.0 * (feature_importance /feature_importance.max())
sorted_idx = np.argsort(feature_importance)
pos = np.arange(sorted_idx.shape[0]) + 0.5
pvals = feature_importance[sorted_idx]
pcols = x_train.columns[sorted_idx]
plt.figure(figsize=(7,8))
plt.barh(pos, pvals, align='center', color='black')
plt.yticks(pos, pcols)
plt.xlabel('Suhteellinen tärkeys muuttujaan')
plt.title('Muuttujan merkitys suhteessa hintaan')

